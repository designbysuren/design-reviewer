---
name: False positive or missed defect
about: The reviewer reported something wrong, or missed something real
---

**Which mode?** SCREEN / CODE / SYSTEM

**Input** (attach the screenshot, or paste the code or docs. A report without the input that produced it cannot be fixed.)

**What it reported**

**What it should have reported**

**Which rule** (for example P6, or a check in code-review.md)
